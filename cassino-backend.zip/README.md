# Cassino Backend

Servidor para cassino online com suporte a MongoDB Atlas e deploy no Render.

## Scripts
- `npm install`: Instalar dependências
- `npm start`: Iniciar servidor

## Variáveis de ambiente
- `MONGO_URI`: sua URL do MongoDB Atlas